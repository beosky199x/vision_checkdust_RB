/*

define xxxx_1: FW1 camera

define xxxx_2: FB1 camera

*/

/*	
xxx_a_b:

	
a: Size Check 

b: Camera type 

0: small size 1: large size

	
1: FW1 2: FB1

*/